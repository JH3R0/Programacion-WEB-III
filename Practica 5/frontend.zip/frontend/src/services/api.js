// Archivo para manejar las peticiones al backend con Axios
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3000/api', // Ruta del backend
});

export default api;
