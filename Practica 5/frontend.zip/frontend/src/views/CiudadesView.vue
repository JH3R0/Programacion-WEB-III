<template>
  <Ciudad />
</template>

<script setup>
import Ciudad from '../components/Ciudad.vue';
</script>
