<template>
  <Pais />
</template>

<script setup>
import Pais from '../components/Pais.vue';
</script>
