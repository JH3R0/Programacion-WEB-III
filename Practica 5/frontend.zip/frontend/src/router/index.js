import { createRouter, createWebHistory } from 'vue-router';
import PaisesView from '../views/PaisesView.vue';
import CiudadesView from '../views/CiudadesView.vue';

const routes = [
  { path: '/', redirect: '/paises' },
  { path: '/paises', component: PaisesView },
  { path: '/ciudades', component: CiudadesView }
];

export default createRouter({
  history: createWebHistory(),
  routes
});
