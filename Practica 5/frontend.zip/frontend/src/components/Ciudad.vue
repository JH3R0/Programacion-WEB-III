<template>
  <div>
    <h3 class="mb-3">Ciudades</h3>

    <button class="btn btn-secondary mb-3" @click="resetFormulario()">Agregar Ciudad</button>

    <form @submit.prevent="guardar" class="row g-2 mb-4">
      <div class="col-md-3">
        <input v-model="form.nombre" placeholder="Nombre" class="form-control" required />
      </div>
      <div class="col-md-2">
        <input v-model.number="form.poblacion" type="number" min="1" placeholder="Población" class="form-control" required />
      </div>
      <div class="col-md-3">
        <input v-model="form.region" placeholder="Región" class="form-control" required />
      </div>
      <div class="col-md-2">
        <select v-model="form.id_pais" class="form-select" required>
          <option disabled value="">Selecciona País</option>
          <option v-for="pais in paises" :key="pais.id_pais" :value="pais.id_pais">
            {{ pais.nombre }}
          </option>
        </select>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-success w-100">
          {{ editando ? 'Actualizar' : 'Agregar' }}
        </button>
      </div>
    </form>

    <table class="table table-bordered shadow rounded">
      <thead class="table-primary">
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Población</th>
          <th>Región</th>
          <th>País</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="ciudad in ciudades" :key="ciudad.id_ciudad">
          <td>{{ ciudad.id_ciudad }}</td>
          <td>{{ ciudad.nombre }}</td>
          <td>{{ ciudad.poblacion }}</td>
          <td>{{ ciudad.region }}</td>
          <td>{{ ciudad.nombre_pais }}</td>
          <td>
            <button class="btn btn-success btn-sm me-1" @click="editar(ciudad)">Editar</button>
            <button class="btn btn-danger btn-sm" @click="eliminar(ciudad.id_ciudad)">Eliminar</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '../services/api';

const ciudades = ref([]);
const paises = ref([]);
const form = ref({
  nombre: '',
  poblacion: 1,
  region: '',
  id_pais: ''
});
const editando = ref(false);
const idEditando = ref(null);

const cargar = async () => {
  const resCiudades = await api.get('/ciudades');
  ciudades.value = resCiudades.data;

  const resPaises = await api.get('/paises');
  paises.value = resPaises.data;
};

const guardar = async () => {
  const regexNombre = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,100}$/;
  const regexRegion = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{4,100}$/;

  if (!regexNombre.test(form.value.nombre) || !regexRegion.test(form.value.region)) {
    alert('Nombre o región inválidos.');
    return;
  }

  if (editando.value) {
    await api.put(`/ciudades/${idEditando.value}`, form.value);
    editando.value = false;
  } else {
    await api.post('/ciudades', form.value);
  }

  resetFormulario();
  cargar();
};

const editar = (ciudad) => {
  form.value = { ...ciudad };
  idEditando.value = ciudad.id_ciudad;
  editando.value = true;
};

const eliminar = async (id) => {
  if (confirm('¿Eliminar esta ciudad?')) {
    await api.delete(`/ciudades/${id}`);
    cargar();
  }
};

const resetFormulario = () => {
  form.value = { nombre: '', poblacion: 1, region: '', id_pais: '' };
  editando.value = false;
};

onMounted(() => {
  cargar();
});
</script>
