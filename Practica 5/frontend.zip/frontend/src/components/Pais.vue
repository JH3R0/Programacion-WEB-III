<template>
  <div>
    <h3 class="mb-3">Países</h3>

    <button class="btn btn-secondary mb-3" @click="resetFormulario()">Agregar País</button>

    <form @submit.prevent="guardar" class="row g-2 mb-4">
      <div class="col-md-3">
        <input v-model="form.nombre" placeholder="Nombre" class="form-control" required />
      </div>
      <div class="col-md-3">
        <input v-model="form.capital" placeholder="Capital" class="form-control" required />
      </div>
      <div class="col-md-3">
        <input v-model="form.continente" placeholder="Continente" class="form-control" required />
      </div>
      <div class="col-md-3">
        <button type="submit" class="btn btn-success w-100">{{ editando ? 'Actualizar' : 'Agregar' }}</button>
      </div>
    </form>

    <table class="table table-bordered shadow rounded">
      <thead class="table-primary">
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Capital</th>
          <th>Continente</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="pais in paises" :key="pais.id_pais">
          <td>{{ pais.id_pais }}</td>
          <td>{{ pais.nombre }}</td>
          <td>{{ pais.capital }}</td>
          <td>{{ pais.continente }}</td>
          <td>
            <button class="btn btn-success btn-sm me-1" @click="editar(pais)">Editar</button>
            <button class="btn btn-danger btn-sm" @click="eliminar(pais.id_pais)">Eliminar</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '../services/api';

const paises = ref([]);
const form = ref({ nombre: '', capital: '', continente: '' });
const editando = ref(false);
const idEditando = ref(null);

const cargar = async () => {
  const res = await api.get('/paises');
  paises.value = res.data;
};

const guardar = async () => {
  const regex = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,100}$/;
  if (!regex.test(form.value.nombre) || !regex.test(form.value.capital)) {
    alert('Nombre y capital inválidos. Solo letras, espacios y entre 2-100 caracteres.');
    return;
  }

  if (editando.value) {
    await api.put(`/paises/${idEditando.value}`, form.value);
    editando.value = false;
  } else {
    await api.post('/paises', form.value);
  }

  form.value = { nombre: '', capital: '', continente: '' };
  cargar();
};

const editar = (pais) => {
  form.value = { ...pais };
  idEditando.value = pais.id_pais;
  editando.value = true;
};

const eliminar = async (id) => {
  if (confirm('¿Eliminar este país?')) {
    await api.delete(`/paises/${id}`);
    cargar();
  }
};

const resetFormulario = () => {
  form.value = { nombre: '', capital: '', continente: '' };
  editando.value = false;
};

onMounted(() => {
  cargar();
});
</script>
