<template>
  <div>
    <nav class="navbar navbar-dark bg-dark px-3">
      <div class="container-fluid">
        <router-link to="/paises" class="btn btn-primary me-2">Países</router-link>
        <router-link to="/ciudades" class="btn btn-primary">Ciudades</router-link>
      </div>
    </nav>
    <div class="container mt-4">
      <router-view />
    </div>
  </div>
</template>
