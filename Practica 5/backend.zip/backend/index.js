// ─────────────────────────────────────────────────────────────
// BACKEND CRUD DE PAÍSES Y CIUDADES CON VALIDACIONES
// ─────────────────────────────────────────────────────────────

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// ─── MIDDLEWARES ─────────────────────────────────────────────
app.use(cors());
app.use(bodyParser.json());

// ─── CONEXIÓN A MYSQL CON PRUEBA ────────────────────────────
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // Cambia si tienes contraseña en XAMPP
  database: 'farmacia_db'
});

// Probar conexión al iniciar
db.getConnection((err, connection) => {
  if (err) {
    console.error('❌ Error al conectar con MySQL:', err.message);
    process.exit(1); // detiene el backend
  }
  console.log('✅ Conectado correctamente a la base de datos MySQL');
  connection.release();
});

// ─── VALIDACIONES CON REGEX ─────────────────────────────────
const regexTexto = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,100}$/;
const regexCiudad = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,100}$/;
const regexRegion = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{4,100}$/;

// ─────────────────────────────────────────────────────────────
// CRUD PAÍSES
// ─────────────────────────────────────────────────────────────

app.get('/api/paises', (req, res) => {
  db.query('SELECT * FROM pais', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

app.post('/api/paises', (req, res) => {
  const { nombre, capital, continente } = req.body;

  if (!regexTexto.test(nombre) || !regexTexto.test(capital)) {
    return res.status(400).json({ error: 'Nombre o capital inválido' });
  }

  db.query(
    'INSERT INTO pais (nombre, capital, continente) VALUES (?, ?, ?)',
    [nombre, capital, continente],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'País agregado correctamente', id_pais: result.insertId });
    }
  );
});

app.put('/api/paises/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, capital, continente } = req.body;

  if (!regexTexto.test(nombre) || !regexTexto.test(capital)) {
    return res.status(400).json({ error: 'Nombre o capital inválido' });
  }

  db.query(
    'UPDATE pais SET nombre=?, capital=?, continente=? WHERE id_pais=?',
    [nombre, capital, continente, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'País actualizado' });
    }
  );
});

app.delete('/api/paises/:id', (req, res) => {
  const { id } = req.params;

  db.query('DELETE FROM pais WHERE id_pais=?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'País eliminado' });
  });
});

// ─────────────────────────────────────────────────────────────
// CRUD CIUDADES
// ─────────────────────────────────────────────────────────────

app.get('/api/ciudades', (req, res) => {
  const sql = `
    SELECT ciudad.*, pais.nombre AS nombre_pais 
    FROM ciudad 
    LEFT JOIN pais ON ciudad.id_pais = pais.id_pais
  `;
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

app.post('/api/ciudades', (req, res) => {
  const { nombre, poblacion, region, id_pais } = req.body;

  if (!regexCiudad.test(nombre) || !regexRegion.test(region)) {
    return res.status(400).json({ error: 'Nombre o región inválido' });
  }

  db.query(
    'INSERT INTO ciudad (nombre, poblacion, region, id_pais) VALUES (?, ?, ?, ?)',
    [nombre, poblacion, region, id_pais],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Ciudad agregada correctamente', id_ciudad: result.insertId });
    }
  );
});

app.put('/api/ciudades/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, poblacion, region, id_pais } = req.body;

  if (!regexCiudad.test(nombre) || !regexRegion.test(region)) {
    return res.status(400).json({ error: 'Nombre o región inválido' });
  }

  db.query(
    'UPDATE ciudad SET nombre=?, poblacion=?, region=?, id_pais=? WHERE id_ciudad=?',
    [nombre, poblacion, region, id_pais, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Ciudad actualizada' });
    }
  );
});

app.delete('/api/ciudades/:id', (req, res) => {
  const { id } = req.params;

  db.query('DELETE FROM ciudad WHERE id_ciudad=?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Ciudad eliminada' });
  });
});

// ─── INICIO DEL SERVIDOR ─────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 Servidor backend corriendo en http://localhost:${PORT}`);
});
